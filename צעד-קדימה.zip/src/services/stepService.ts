import { 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  orderBy, 
  onSnapshot,
  increment,
  Timestamp,
  serverTimestamp,
  limit
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { format } from 'date-fns';

export interface UserProfile {
  uid: string;
  displayName: string;
  email?: string;
  photoURL?: string;
  dailyGoal: number;
  totalSteps: number;
  lastSync?: any;
  agreedToTerms?: boolean;
  marketingConsent?: boolean;
}

export interface StepHistoryRecord {
  id?: string;
  date: string;
  steps: number;
  calories: number;
  distance: number;
  userId: string;
}

export const syncUserProfile = async (user: any, agreed: boolean = true, marketing: boolean = false) => {
  const userRef = doc(db, 'users', user.uid);
  try {
    const userDoc = await getDoc(userRef);
    if (!userDoc.exists()) {
      const initialProfile = {
        displayName: user.displayName || 'User',
        email: user.email || '',
        photoURL: user.photoURL || '',
        dailyGoal: 10000,
        totalSteps: 0,
        lastSync: serverTimestamp(),
        agreedToTerms: agreed,
        marketingConsent: marketing
      };
      await setDoc(userRef, initialProfile);
      return initialProfile;
    }
    return userDoc.data() as UserProfile;
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}`);
  }
};

export const updateDailySteps = async (userId: string, steps: number) => {
  const dateStr = format(new Date(), 'yyyy-MM-dd');
  const recordRef = doc(db, 'users', userId, 'history', dateStr);
  const userRef = doc(db, 'users', userId);

  try {
    const recordDoc = await getDoc(recordRef);
    const calories = Math.floor(steps * 0.04);
    const distance = Number((steps * 0.0008).toFixed(2));

    if (recordDoc.exists()) {
      const existingSteps = recordDoc.data().steps;
      const stepDiff = steps - existingSteps;
      
      if (stepDiff > 0) {
        await setDoc(recordRef, {
          steps,
          calories,
          distance,
          updatedAt: serverTimestamp()
        }, { merge: true });

        await setDoc(userRef, {
          totalSteps: increment(stepDiff),
          lastSync: serverTimestamp()
        }, { merge: true });
      }
    } else {
      await setDoc(recordRef, {
        userId,
        date: dateStr,
        steps,
        calories,
        distance,
        createdAt: serverTimestamp()
      });
      
      await setDoc(userRef, {
        totalSteps: increment(steps),
        lastSync: serverTimestamp()
      }, { merge: true });
    }
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `users/${userId}/history/${dateStr}`);
  }
};

export const getStepHistory = async (userId: string, dayLimit: number = 7) => {
  const historyRef = collection(db, 'users', userId, 'history');
  const q = query(historyRef, orderBy('date', 'desc'), limit(dayLimit));
  
  try {
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as StepHistoryRecord));
  } catch (e) {
    handleFirestoreError(e, OperationType.LIST, `users/${userId}/history`);
    return [];
  }
};

export const subscribeToProfile = (userId: string, callback: (profile: UserProfile) => void) => {
  return onSnapshot(doc(db, 'users', userId), (doc) => {
    if (doc.exists()) {
      callback({ uid: userId, ...doc.data() } as UserProfile);
    }
  });
};
