import { 
  collection, 
  doc, 
  addDoc, 
  setDoc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  deleteDoc,
  serverTimestamp,
  collectionGroup
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';

export interface Team {
  id?: string;
  name: string;
  creatorId: string;
  inviteCode: string;
  createdAt: any;
}

export interface TeamMember {
  id?: string;
  teamId: string;
  userId: string;
  joinedAt: any;
  displayName?: string;
  photoURL?: string;
}

export const createTeam = async (name: string) => {
  const user = auth.currentUser;
  if (!user) throw new Error("Must be signed in");

  const inviteCode = Math.random().toString(36).substring(2, 8).toUpperCase();
  
  try {
    const teamRef = await addDoc(collection(db, 'teams'), {
      name,
      creatorId: user.uid,
      inviteCode,
      createdAt: serverTimestamp()
    });

    await setDoc(doc(db, 'teams', teamRef.id, 'members', user.uid), {
      teamId: teamRef.id,
      userId: user.uid,
      joinedAt: serverTimestamp()
    });

    return teamRef.id;
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'teams');
  }
};

export const joinTeam = async (inviteCode: string) => {
  const user = auth.currentUser;
  if (!user) throw new Error("Must be signed in");

  try {
    const q = query(collection(db, 'teams'), where('inviteCode', '==', inviteCode));
    const snapshot = await getDocs(q);
    
    if (snapshot.empty) throw new Error("Invalid invite code");
    
    const teamId = snapshot.docs[0].id;
    await setDoc(doc(db, 'teams', teamId, 'members', user.uid), {
      teamId,
      userId: user.uid,
      joinedAt: serverTimestamp()
    });
    
    return teamId;
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'teams/join');
  }
};

export const getMyTeams = async () => {
  const user = auth.currentUser;
  if (!user) return [];

  try {
    // We can't use collectionGroup easily without indexes, 
    // so we'll query teams and filter in memory or use a direct mapping if needed.
    // For simplicity with Firestore rules and indexing, we'll use a flattened structure or simple query.
    // Actually, rules allow list on teams.
    const snapshot = await getDocs(collection(db, 'teams'));
    const teamsWithMe = [];
    
    for (const teamDoc of snapshot.docs) {
      const memberDoc = await getDoc(doc(db, 'teams', teamDoc.id, 'members', user.uid));
      if (memberDoc.exists()) {
        teamsWithMe.push({ id: teamDoc.id, ...teamDoc.data() } as Team);
      }
    }
    return teamsWithMe;
  } catch (e) {
    handleFirestoreError(e, OperationType.LIST, 'teams');
    return [];
  }
};

export const getTeamMembers = async (teamId: string) => {
  try {
    const membersRef = collection(db, 'teams', teamId, 'members');
    const snapshot = await getDocs(membersRef);
    const members = [];
    
    for (const memberDoc of snapshot.docs) {
      const data = memberDoc.data();
      const userProfileDoc = await getDoc(doc(db, 'users', data.userId));
      members.push({
        ...data,
        id: memberDoc.id,
        displayName: userProfileDoc.exists() ? userProfileDoc.data().displayName : 'Unknown',
        photoURL: userProfileDoc.exists() ? userProfileDoc.data().photoURL : ''
      });
    }
    return members as TeamMember[];
  } catch (e) {
    handleFirestoreError(e, OperationType.LIST, `teams/${teamId}/members`);
    return [];
  }
};
