export interface StepData {
  timestamp: number;
  magnitude: number;
}

export class StepDetector {
  private threshold = 1.4; // Slightly more sensitive
  private cooldown = 300; // Faster response
  private lastStepTime = 0;
  private onStep: () => void;
  private lastMagnitude = 9.8;
  private alpha = 0.92; // Better smoothing for the baseline gravity

  constructor(onStep: () => void) {
    this.onStep = onStep;
  }

  public handleMotion(event: DeviceMotionEvent) {
    const acc = event.accelerationIncludingGravity;
    if (!acc || acc.x === null || acc.y === null || acc.z === null) return;

    // Calculate magnitude
    const magnitude = Math.sqrt(acc.x ** 2 + acc.y ** 2 + acc.z ** 2);
    
    // Low pass filter to find local gravity baseline
    this.lastMagnitude = this.alpha * this.lastMagnitude + (1 - this.alpha) * magnitude;
    
    const delta = magnitude - this.lastMagnitude;

    const now = Date.now();
    
    // We look for a peak that is significantly higher than the baseline
    // and ensure we don't count too many steps too fast
    if (delta > this.threshold && now - this.lastStepTime > this.cooldown) {
      this.lastStepTime = now;
      this.onStep();
    }
  }
}
