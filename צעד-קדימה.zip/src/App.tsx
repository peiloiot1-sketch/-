import { useState, useEffect, useRef } from 'react';
import { 
  Activity, 
  Users, 
  Trophy, 
  MapPin, 
  Zap,
  TrendingUp,
  Award,
  Plus,
  ArrowRight,
  LogOut,
  Share2,
  Copy,
  Check,
  Footprints,
  Star,
  ZapIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { StepDetector } from './services/stepDetection.ts';
import { doc, setDoc, collection, getDocs } from 'firebase/firestore';
import { db, auth, signInWithGoogle, logout } from './lib/firebase';
import { 
  syncUserProfile, 
  updateDailySteps, 
  getStepHistory,
  subscribeToProfile,
  UserProfile,
  StepHistoryRecord
} from './services/stepService';
import { 
  getMyTeams, 
  joinTeam, 
  createTeam, 
  Team 
} from './services/teamService';
import { HistoryChart } from './components/HistoryChart';

const STREAK_BONUSES = [
  { days: 2, name: 'זוג מנצח', color: 'bg-blue-500' },
  { days: 3, name: 'התחלה מבטיחה', color: 'bg-green-500' },
  { days: 5, name: 'חמישייה חזקה', color: 'bg-yellow-500' },
  { days: 7, name: 'שבוע הפלאות', color: 'bg-purple-500' },
  { days: 10, name: 'בונה הרגלים', color: 'bg-orange-500' },
  { days: 20, name: 'מסירות ללא גבולות', color: 'bg-pink-500' },
  { days: 35, name: 'מרתוניסט', color: 'bg-red-500' },
  { days: 50, name: 'אגדה מהלכת', color: 'bg-indigo-500' },
  { days: 65, name: 'בלתי ניתן לעצירה', color: 'bg-cyan-500' },
];

const Logo = ({ size = 'md', dark = false }: { size?: 'sm' | 'md' | 'lg', dark?: boolean }) => {
  const iconSize = size === 'sm' ? 18 : size === 'md' ? 24 : 40;
  const containerSize = size === 'sm' ? 'w-8 h-8' : size === 'md' ? 'w-10 h-10' : 'w-20 h-20';
  const fontSize = size === 'sm' ? 'text-lg' : size === 'md' ? 'text-2xl' : 'text-5xl';
  
  return (
    <div className={`flex items-center ${size === 'lg' ? 'flex-col gap-4' : 'gap-3'}`}>
      <div className={`${containerSize} bg-brand-primary rounded-2xl flex items-center justify-center text-white shadow-xl shadow-brand-primary/20 transform rotate-6 animate-pulse`}>
        <Activity size={iconSize} strokeWidth={2.5} />
      </div>
      <div className={`flex flex-col ${size === 'lg' ? 'items-center' : ''}`}>
        <h1 className={`${fontSize} font-serif font-black tracking-tight ${dark ? 'text-white' : 'text-text-heading'} leading-none`}>
          צעד קדימה
        </h1>
        {size !== 'sm' && (
          <span className={`text-[9px] font-bold uppercase tracking-[0.3em] ${dark ? 'text-white/40' : 'text-brand-primary/60'} mt-1`}>
            Inspired Motion
          </span>
        )}
      </div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [steps, setSteps] = useState(0);
  const [isCounting, setIsCounting] = useState(false);
  const [activeTab, setActiveTab] = useState<'daily' | 'teams' | 'rewards'>('daily');
  const [history, setHistory] = useState<StepHistoryRecord[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteCode, setInviteCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [marketing, setMarketing] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [showCreateTeamModal, setShowCreateTeamModal] = useState(false);
  const [newTeamName, setNewTeamName] = useState('');
  const [tempGoal, setTempGoal] = useState(10000);
  const [stepEffect, setStepEffect] = useState(false);

  const detectorRef = useRef<StepDetector | null>(null);

  const handleUpdateGoal = async () => {
    if (!user) return;
    try {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, { dailyGoal: tempGoal }, { merge: true });
      setProfile(prev => prev ? { ...prev, dailyGoal: tempGoal } : null);
      setShowGoalModal(false);
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateTeam = async () => {
    if (!newTeamName) return;
    await createTeam(newTeamName);
    setNewTeamName('');
    setShowCreateTeamModal(false);
    if (user) loadData(user.uid);
  };

  // Authentication & Profile Sync
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (u) => {
      setUser(u);
      if (u) {
        const p = await syncUserProfile(u);
        setProfile(p || null);
        loadData(u.uid);
      } else {
        setProfile(null);
        setHistory([]);
        setTeams([]);
      }
    });
    return unsubscribe;
  }, []);

  // Step Detector Lifecycle
  useEffect(() => {
    detectorRef.current = new StepDetector(() => {
      setSteps(prev => {
        const next = prev + 1;
        setStepEffect(true);
        setTimeout(() => setStepEffect(false), 200);
        // Periodic sync to backend
        if (next % 10 === 0 && user) {
          updateDailySteps(user.uid, next);
        }
        return next;
      });
    });
  }, [user]);

  const loadData = async (uid: string) => {
    const [h, t] = await Promise.all([
      getStepHistory(uid),
      getMyTeams()
    ]);
    setHistory(h);
    setTeams(t);
    
    // Find today's steps in history
    const today = new Date().toISOString().split('T')[0];
    const todayRecord = h.find(r => r.date === today);
    if (todayRecord) {
      setSteps(todayRecord.steps);
    }
  };

  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleSignIn = async () => {
    if (!agreed) return;
    setIsLoggingIn(true);
    try {
      const u = await signInWithGoogle();
      if (u) {
        await syncUserProfile(u, agreed, marketing);
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const exportUsers = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'users'));
      const marketingUsers = snapshot.docs
        .map(d => d.data() as UserProfile)
        .filter(u => u.marketingConsent);
      
      const body = marketingUsers
        .map(u => `${u.displayName} (${u.email})`)
        .join('\n');
      
      const mailto = `mailto:?subject=StepUp Marketing List&body=${encodeURIComponent(body)}`;
      window.location.href = mailto;
    } catch (e) {
      console.error(e);
    }
  };

  const requestPermission = async () => {
    if (typeof (DeviceMotionEvent as any).requestPermission === 'function') {
      try {
        const response = await (DeviceMotionEvent as any).requestPermission();
        if (response === 'granted') startCounting();
      } catch (e) {
        console.error(e);
      }
    } else {
      startCounting();
    }
  };

  const startCounting = () => {
    if (isCounting) return;
    window.addEventListener('devicemotion', handleMotion);
    setIsCounting(true);
  };

  const stopCounting = () => {
    window.removeEventListener('devicemotion', handleMotion);
    setIsCounting(false);
    if (user) {
      updateDailySteps(user.uid, steps);
    }
  };

  const handleMotion = (e: DeviceMotionEvent) => {
    detectorRef.current?.handleMotion(e);
  };

  const handleJoinTeam = async () => {
    if (!inviteCode) return;
    await joinTeam(inviteCode);
    setInviteCode('');
    setShowInviteModal(false);
    if (user) loadData(user.uid);
  };

  const copyProfileLink = () => {
    const link = `${window.location.origin}/user/${user?.uid}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const RANKS = [
    { name: 'זוטר', threshold: 0 },
    { name: 'מתלמד', threshold: 1000 },
    { name: 'חובב', threshold: 3000 },
    { name: 'רץ', threshold: 6000 },
    { name: 'אתלט', threshold: 10000 },
    { name: 'לוחם', threshold: 15000 },
    { name: 'מקצוען', threshold: 21000 },
    { name: 'מומחה', threshold: 28000 },
    { name: 'אלוף', threshold: 36000 },
    { name: 'גיבור', threshold: 45000 },
    { name: 'אגדה', threshold: 55000 },
    { name: 'קיסר', threshold: 66000 },
    { name: 'מלך', threshold: 78000 },
  ];

  // Calculate League based on total steps
  const getLeagueInfo = () => {
    const total = profile?.totalSteps || 0;
    let currentRank = RANKS[0];
    let nextRank = RANKS[1];

    for (let i = 0; i < RANKS.length; i++) {
      if (total >= RANKS[i].threshold) {
        currentRank = RANKS[i];
        nextRank = RANKS[i + 1] || null;
      } else {
        break;
      }
    }

    const progress = nextRank 
      ? ((total - currentRank.threshold) / (nextRank.threshold - currentRank.threshold)) * 100
      : 100;

    const remaining = nextRank ? nextRank.threshold - total : 0;

    return { currentRank, nextRank, progress, remaining };
  };

  const league = getLeagueInfo();

  // Calculate current streak
  const getStreak = () => {
    if (!history.length) return 0;
    let streak = 0;
    const sortedHistory = [...history].sort((a, b) => b.date.localeCompare(a.date));
    
    for (let i = 0; i < sortedHistory.length; i++) {
      if (sortedHistory[i].steps >= (profile?.dailyGoal || 10000)) {
        streak++;
      } else if (i === 0) {
        // If today or the most recent day isn't met, check if it's actually today 
        // (maybe the user just hasn't finished walking yet). 
        // For simplicity, we just break.
        continue;
      } else {
        break;
      }
    }
    return streak;
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-bg-main flex flex-col items-center justify-center p-8 text-center sm:p-20" dir="rtl">
        <Logo size="lg" />
        <div className="mt-12 space-y-6 w-full max-w-sm">
          <p className="text-lg text-text-main opacity-70">
            הצטרף לאלפי אנשים שהופכים כל צעד לאתגר קבוצתי ולחיים בריאים יותר.
          </p>

          <div className="bg-white p-6 rounded-[32px] border border-border-main space-y-4 text-right">
            <div className="flex items-start gap-3">
              <input 
                id="terms"
                type="checkbox" 
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                className="mt-1 w-5 h-5 rounded border-border-main text-brand-primary focus:ring-brand-primary"
              />
              <label htmlFor="terms" className="text-xs font-semibold text-text-main/70 leading-relaxed cursor-pointer">
                אני מאשר את <button onClick={() => setShowTerms(true)} className="text-brand-primary underline underline-offset-2">תקנון השימוש</button> ומדיניות הפרטיות. אני מבין שהשימוש באפליקציה הוא על אחריותי בלבד והחברה לא תישא באחריות לכל נזק גופני או אחר.
              </label>
            </div>
            
            <div className="flex items-start gap-3">
              <input 
                id="marketing"
                type="checkbox" 
                checked={marketing}
                onChange={(e) => setMarketing(e.target.checked)}
                className="mt-1 w-5 h-5 rounded border-border-main text-brand-primary focus:ring-brand-primary"
              />
              <label htmlFor="marketing" className="text-xs font-semibold text-text-main/70 leading-relaxed cursor-pointer">
                אני מאשר קבלת עדכונים, הצעות שיווקיות ודיוור ישיר (רשות).
              </label>
            </div>
          </div>

          <button 
            onClick={handleSignIn}
            disabled={!agreed || isLoggingIn}
            className={`w-full bg-white border border-border-main text-text-main py-5 rounded-[24px] font-bold flex items-center justify-center gap-4 shadow-sm transition-all transform ${!agreed || isLoggingIn ? 'opacity-30 grayscale cursor-not-allowed' : 'hover:bg-bg-soft hover:scale-[1.02] active:scale-95'}`}
          >
            {isLoggingIn ? (
              <div className="w-6 h-6 border-2 border-brand-primary border-t-transparent rounded-full animate-spin" />
            ) : (
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-6 h-6" alt="Google" />
            )}
            {isLoggingIn ? 'מתחבר...' : 'התחבר באמצעות Google'}
          </button>
        </div>

        {/* Legal Modal */}
        <AnimatePresence>
          {showTerms && (
            <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
              <motion.div 
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                onClick={() => setShowTerms(false)}
                className="absolute inset-0 bg-text-heading/40 backdrop-blur-sm" 
              />
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                className="bg-white w-full max-w-lg max-h-[80vh] overflow-y-auto rounded-[40px] p-10 shadow-2xl relative z-210 border border-border-main text-right"
              >
                <h3 className="text-2xl font-serif font-bold text-text-heading mb-6">תקנון ותנאי שימוש - צעד קדימה</h3>
                <div className="prose prose-sm text-text-main/80 space-y-4 font-medium leading-relaxed">
                  <p>1. <strong>הגבלת אחריות:</strong> האפליקציה נועדה למטרות פנאי וכושר כללי בלבד. המפעיל אינו אחראי לכל נזק בריאותי, גופני או נפשי שעלול להיגרם כתוצאה מהשימוש באפליקציה או מביצוע פעילות גופנית המבוססת על נתוניה.</p>
                  <p>2. <strong>חובת התייעצות:</strong> על המשתמש להיוועץ ברופא מוסמך לפני תחילת כל פעילות גופנית אינטנסיבית. השימוש באפליקציה על ידי משתמשים עם בעיות רקע רפואיות אסור בהחלט.</p>
                  <p>3. <strong>דיוק הנתונים:</strong> נתוני הצעדים, המרחק והקלוריות הם הערכה בלבד ומבוססים על חיישני המכשיר. אין להסתמך עליהם לצרכים רפואיים או מקצועיים.</p>
                  <p>4. <strong>פרטיות ושיווק:</strong> בסימון תיבת הדיוור, הנך מאשר למפעיל לאסוף את נתוני הפעילות שלך ולשלוח לך מידע פרסומי, הצעות מותאמות אישית ועדכונים.</p>
                  <p>5. <strong>שימוש במידע:</strong> המידע שנאסף עשוי לשמש לשיפור השירות, לניתוחים סטטיסטיים ולמטרות עסקיות של המפעיל, בכפוף למדיניות הפרטיות.</p>
                  <p>6. <strong>שיפוי:</strong> המשתמש מתחייב לשפות את המפעיל בגין כל תביעה או דרישה של צד שלישי שתנבע משימוש לא תקין באפליקציה.</p>
                </div>
                <button 
                  onClick={() => setShowTerms(false)}
                  className="w-full mt-8 bg-brand-primary text-white py-4 rounded-2xl font-bold hover:opacity-90 transition-all"
                >
                  סגור והבנתי
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-main text-text-main font-sans selection:bg-brand-primary/20 overflow-y-auto" dir="rtl">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 h-20 bg-bg-main/80 backdrop-blur-md border-b border-border-main z-50 flex items-center justify-between px-8 md:px-12">
        <Logo size="sm" />
        
        <div className="flex items-center gap-4">
          <div className="hidden sm:flex flex-col items-end mr-4">
            <span className="text-[10px] uppercase font-bold tracking-widest opacity-40 leading-none block mb-0.5">שלום,</span>
            <h1 className="text-sm font-serif font-bold tracking-tight text-text-heading">היי {profile?.displayName?.split(' ')[0]}</h1>
          </div>
          <div className="hidden sm:flex flex-col items-end mr-4 cursor-pointer hover:opacity-70 transition-opacity" onClick={() => { setTempGoal(profile?.dailyGoal || 10000); setShowGoalModal(true); }}>
            <span className="text-[10px] uppercase tracking-widest opacity-60 font-bold">יעד יומי</span>
            <span className="text-xs font-mono font-bold text-brand-primary">{profile?.dailyGoal?.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={exportUsers}
              className="p-2.5 bg-white rounded-full border border-border-main text-text-main/60 hover:text-brand-primary hover:border-brand-primary/30 transition-all shadow-sm"
              title="ייצוא רשימת שיווק"
            >
              <Users size={18} />
            </button>
            <button 
              onClick={copyProfileLink}
              className="p-2.5 bg-white rounded-full border border-border-main text-text-main/60 hover:text-brand-primary hover:border-brand-primary/30 transition-all shadow-sm"
              title="שתף פרופיל"
            >
              {copied ? <Check size={18} /> : <Share2 size={18} />}
            </button>
            <button 
              onClick={logout}
              className="p-2.5 bg-white rounded-full border border-border-main text-text-main/60 hover:text-red-500 hover:border-red-100 transition-all shadow-sm"
              title="התנתק"
            >
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-28 pb-32 px-6 max-w-4xl mx-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'daily' && (
            <motion.div
              key="daily"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-10"
            >
              {/* Step Display Card */}
              <div className="bg-white rounded-[48px] shadow-sm border border-border-main p-10 flex flex-col items-center justify-center relative overflow-hidden text-center">
                <div className="absolute top-0 right-0 w-32 h-32 bg-brand-primary opacity-10 rounded-full -mr-16 -mt-16" />
                <div className="absolute bottom-0 left-0 w-48 h-48 bg-brand-secondary opacity-10 rounded-full -ml-24 -mb-24" />
                
                <span className="text-sm uppercase tracking-widest opacity-60 mb-2 font-bold">היום, {new Date().toLocaleDateString('he-IL', { day: 'numeric', month: 'long' })}</span>
                <div className="relative">
                  <h2 className={`text-[100px] md:text-[120px] font-serif leading-none text-text-heading mb-2 tracking-tighter tabular-nums transition-all duration-100 ${stepEffect ? 'scale-110 text-brand-primary' : 'scale-100'}`}>
                    {steps.toLocaleString()}
                  </h2>
                  <div className={`absolute -top-4 -left-6 transition-all duration-300 ${stepEffect ? 'scale-150 opacity-100' : 'scale-50 opacity-0'}`}>
                    <Zap className="text-brand-secondary fill-brand-secondary" size={32} />
                  </div>
                </div>
                <p className="text-xl font-medium opacity-70 mb-10 font-serif italic">צעדים היום</p>

                <div className="w-full max-w-[320px]">
                  <div className="w-full bg-bg-soft h-4 rounded-full overflow-hidden mb-4 p-1 shadow-inner">
                    <div 
                      className="bg-brand-primary h-full rounded-full transition-all duration-1000 shadow-sm" 
                      style={{ width: `${Math.min((steps / (profile?.dailyGoal || 10000)) * 100, 100)}%` }}
                    />
                  </div>
                  <div className="w-full flex justify-between text-xs font-bold uppercase tracking-tight opacity-60">
                    <span>0</span>
                    <span className="text-brand-primary">יעד: {profile?.dailyGoal}</span>
                  </div>
                </div>

                <div className="mt-8 flex items-center gap-6">
                  <div className="flex items-center gap-2 text-text-main/60">
                    <MapPin size={16} />
                    <span className="text-xs font-bold">{(steps * 0.0008).toFixed(1)} ק״מ</span>
                  </div>
                  <div className="flex items-center gap-2 text-text-main/60">
                    <Zap size={16} className="text-brand-secondary" />
                    <span className="text-xs font-bold">{Math.floor(steps * 0.04)} קק״ל</span>
                  </div>
                </div>
              </div>

              {/* Start/Stop Button */}
              <div className="flex items-center justify-center">
                {!isCounting ? (
                  <button 
                    onClick={requestPermission}
                    className="group relative w-full max-w-sm bg-text-heading text-white py-5 rounded-[32px] font-bold text-lg flex items-center justify-center gap-3 transition-all hover:scale-[1.02] shadow-xl hover:shadow-brand-primary/20 active:scale-95"
                  >
                    <Activity size={24} className="group-hover:rotate-12 transition-transform" />
                    התחל מעקב
                  </button>
                ) : (
                  <button 
                    onClick={stopCounting}
                    className="w-full max-w-sm bg-white border-2 border-text-heading text-text-heading py-5 rounded-[32px] font-bold text-lg flex items-center justify-center gap-3 hover:bg-bg-soft transition-colors active:scale-95"
                  >
                    <Activity size={24} className="animate-pulse text-brand-secondary" />
                    מעקב פעיל...
                  </button>
                )}
              </div>

              {/* History Section */}
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-serif font-bold">היסטוריית פעילות</h3>
                  <div className="flex gap-2">
                    <div className="w-3 h-3 bg-brand-primary rounded-full" />
                    <span className="text-[10px] uppercase font-bold opacity-40">פעילות שבועית</span>
                  </div>
                </div>
                
                <div className="bg-white p-6 rounded-[40px] shadow-sm border border-border-main">
                  {history.length > 0 ? (
                    <HistoryChart data={history.map(h => ({ date: h.date, steps: h.steps }))} />
                  ) : (
                    <div className="h-44 flex items-center justify-center text-text-main/40 italic text-sm">
                      אין עדיין נתוני היסטוריה להצגה
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'teams' && (
            <motion.div
              key="teams"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-serif font-bold text-text-heading">הקבוצות שלי</h2>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setShowInviteModal(true)}
                    className="h-11 px-6 bg-white rounded-full border border-border-main flex items-center justify-center text-text-main font-bold text-sm hover:bg-bg-soft transition-all shadow-sm"
                  >
                    הצטרף עם קוד
                  </button>
                  <button 
                    onClick={() => setShowCreateTeamModal(true)}
                    className="w-11 h-11 bg-brand-primary rounded-full flex items-center justify-center text-white hover:opacity-90 transition-all shadow-sm"
                  >
                    <Plus size={24} />
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                {teams.length > 0 ? teams.map((team, i) => (
                  <div key={i} className="bg-white p-6 rounded-[32px] border border-border-main hover:border-brand-primary/30 transition-all cursor-pointer group shadow-sm">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-bg-soft rounded-2xl flex items-center justify-center text-brand-primary group-hover:bg-brand-primary group-hover:text-white transition-all">
                          <Users size={28} />
                        </div>
                        <div>
                          <h3 className="font-serif font-bold text-lg text-text-heading">{team.name}</h3>
                          <div className="flex items-center gap-2">
                             <div className="flex items-center gap-1 text-[10px] font-bold text-text-main/40 uppercase bg-bg-soft px-2 py-0.5 rounded-full">
                               <Copy size={10} />
                               קוד: {team.inviteCode}
                             </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-left">
                        <div className="font-serif font-bold text-xl">#1</div>
                        <div className="text-[10px] font-bold text-green-600 uppercase">מובילים</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex -space-x-3 space-x-reverse">
                        {[1, 2, 3].map((_, j) => (
                          <div key={j} className="w-8 h-8 rounded-full border-2 border-white bg-bg-soft flex items-center justify-center overflow-hidden">
                            <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${j}`} alt="User" />
                          </div>
                        ))}
                      </div>
                      <ArrowRight size={20} className="text-border-main group-hover:text-brand-primary transition-colors" />
                    </div>
                  </div>
                )) : (
                  <div className="py-20 text-center space-y-4">
                    <div className="w-16 h-16 bg-bg-soft rounded-full flex items-center justify-center mx-auto text-text-main/20">
                      <Users size={32} />
                    </div>
                    <p className="text-sm font-medium text-text-main/40 italic">לא הצטרפת עדיין לאף קבוצה</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === 'rewards' && (
            <motion.div
              key="rewards"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-10"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-serif font-bold text-text-heading">בונוסים והישגים</h2>
                <div className="flex items-center gap-2 text-brand-primary">
                  <ZapIcon size={18} />
                  <span className="font-bold text-sm tracking-widest uppercase">STREAK: {getStreak()}</span>
                </div>
              </div>
              
              {/* League Card */}
              <div className="bg-brand-primary p-8 rounded-[40px] text-white overflow-hidden relative shadow-lg shadow-brand-primary/20">
                <Trophy className="absolute -left-4 -bottom-4 opacity-10 w-48 h-48" />
                <div className="relative z-10">
                  <span className="text-[10px] uppercase tracking-widest font-bold opacity-80">דרגה נוכחית</span>
                  <div className="text-4xl font-serif font-bold mb-4">{league.currentRank.name}</div>
                  <div className="w-full bg-white/20 h-3 rounded-full mb-3 p-0.5 shadow-inner">
                    <div 
                      className="bg-white h-full rounded-full shadow-sm transition-all duration-1000" 
                      style={{ width: `${league.progress}%` }}
                    />
                  </div>
                  <p className="text-xs font-semibold opacity-90 text-right">
                    {league.nextRank ? `${league.remaining.toLocaleString()} צעדים עד לדרגת ${league.nextRank.name}` : 'הגעת לדרגת מלך!'}
                  </p>
                </div>
              </div>

              {/* Bonus Milestones */}
              <div className="space-y-6">
                <h3 className="text-lg font-serif font-bold opacity-60">בונוסי רצף</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {STREAK_BONUSES.map((bonus, i) => {
                    const isUnlocked = getStreak() >= bonus.days;
                    return (
                      <div 
                        key={i} 
                        className={`p-6 rounded-[32px] border transition-all ${isUnlocked ? 'bg-white border-brand-primary/30 shadow-md transform hover:scale-105' : 'bg-bg-soft border-border-main opacity-50 grayscale'}`}
                      >
                        <div className={`w-10 h-10 ${bonus.color} rounded-xl flex items-center justify-center text-white mb-4 shadow-sm`}>
                          <Star size={20} fill={isUnlocked ? 'currentColor' : 'none'} />
                        </div>
                        <h4 className="font-bold text-sm text-text-heading mb-1">{bonus.name}</h4>
                        <p className="text-[10px] font-bold opacity-40 uppercase tracking-widest">{bonus.days} ימים רצופים</p>
                        {isUnlocked && (
                          <div className="mt-3 flex items-center gap-1 text-[10px] font-bold text-brand-primary uppercase">
                            <Check size={10} />
                            בוצע
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Stats Highlights */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-6 rounded-[32px] border border-border-main flex items-center gap-5 shadow-sm">
                  <div className="w-14 h-14 bg-bg-soft rounded-2xl flex items-center justify-center text-brand-neutral shrink-0">
                    <Award size={32} />
                  </div>
                  <div className="overflow-hidden">
                    <h3 className="font-serif font-bold text-lg text-text-heading truncate">שיא אישי</h3>
                    <p className="text-xs text-text-main/60 font-medium font-serif italic line-clamp-1">היעד הגבוה ביותר שהושג</p>
                  </div>
                  <div className="mr-auto text-sm font-bold text-brand-primary bg-bg-soft px-3 py-1 rounded-full italic font-serif">
                    {Math.max(...(history.map(h => h.steps).concat(steps))).toLocaleString()}
                  </div>
                </div>

                <div className="bg-white p-6 rounded-[32px] border border-border-main flex items-center gap-5 shadow-sm">
                   <div className="w-14 h-14 bg-bg-soft rounded-2xl flex items-center justify-center text-brand-neutral shrink-0">
                    <TrendingUp size={32} />
                  </div>
                  <div className="overflow-hidden">
                    <h3 className="font-serif font-bold text-lg text-text-heading truncate">צעדים מצטברים</h3>
                    <p className="text-xs text-text-main/60 font-medium font-serif italic line-clamp-1">סה״כ מאז פתיחת החשבון</p>
                  </div>
                  <div className="mr-auto text-sm font-bold text-text-main/40 bg-bg-soft px-3 py-1 rounded-full italic font-serif">
                    {profile?.totalSteps?.toLocaleString()}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Create Team Modal */}
      <AnimatePresence>
        {showCreateTeamModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCreateTeamModal(false)}
              className="absolute inset-0 bg-text-heading/20 backdrop-blur-sm" 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-sm rounded-[40px] p-8 shadow-2xl relative z-110 border border-border-main"
            >
              <h3 className="text-2xl font-serif font-bold text-text-heading mb-2">צור קבוצה חדשה</h3>
              <p className="text-sm text-text-main/60 mb-6 font-medium">תן שם לקבוצה שלך והזמן חברים לתחרות!</p>
              
              <div className="space-y-4">
                <input 
                  type="text" 
                  value={newTeamName}
                  onChange={(e) => setNewTeamName(e.target.value)}
                  placeholder="שם הקבוצה..."
                  className="w-full bg-bg-soft border border-border-main rounded-2xl py-4 px-6 text-right font-bold focus:outline-none focus:border-brand-primary/50 transition-all"
                />
                <button 
                  onClick={handleCreateTeam}
                  disabled={!newTeamName}
                  className="w-full bg-brand-primary text-white py-4 rounded-2xl font-bold hover:opacity-90 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  צור קבוצה
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Goal Modal */}
      <AnimatePresence>
        {showGoalModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowGoalModal(false)}
              className="absolute inset-0 bg-text-heading/20 backdrop-blur-sm" 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-sm rounded-[40px] p-8 shadow-2xl relative z-110 border border-border-main"
            >
              <h3 className="text-2xl font-serif font-bold text-text-heading mb-2">הגדר יעד יומי</h3>
              <p className="text-sm text-text-main/60 mb-6 font-medium">כמה צעדים תרצה ללכת בכל יום?</p>
              
              <div className="space-y-6">
                <div className="flex flex-col gap-4">
                   <div className="text-center text-4xl font-serif font-bold text-brand-primary">
                     {tempGoal.toLocaleString()}
                   </div>
                   <input 
                    type="range" 
                    min={1000}
                    max={30000}
                    step={1000}
                    value={tempGoal}
                    onChange={(e) => setTempGoal(Number(e.target.value))}
                    className="w-full h-2 bg-bg-soft rounded-lg appearance-none cursor-pointer accent-brand-primary"
                  />
                </div>
                <button 
                  onClick={handleUpdateGoal}
                  className="w-full bg-brand-primary text-white py-4 rounded-2xl font-bold hover:opacity-90 transition-all"
                >
                  עדכן יעד
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showInviteModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowInviteModal(false)}
              className="absolute inset-0 bg-text-heading/20 backdrop-blur-sm" 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-sm rounded-[40px] p-8 shadow-2xl relative z-110 border border-border-main"
            >
              <h3 className="text-2xl font-serif font-bold text-text-heading mb-2">הצטרף לקבוצה</h3>
              <p className="text-sm text-text-main/60 mb-6 font-medium">הזן את קוד ההזמנה בן 6 התווים שקיבלת מהחברים שלך.</p>
              
              <div className="space-y-4">
                <input 
                  type="text" 
                  maxLength={6}
                  value={inviteCode}
                  onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                  placeholder="X J 4 8 R T"
                  className="w-full bg-bg-soft border border-border-main rounded-2xl py-4 px-6 text-center text-2xl font-mono font-bold tracking-[8px] focus:outline-none focus:border-brand-primary/50 transition-all uppercase"
                />
                <button 
                  onClick={handleJoinTeam}
                  disabled={inviteCode.length < 6}
                  className="w-full bg-brand-primary text-white py-4 rounded-2xl font-bold hover:opacity-90 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  הצטרף עכשיו
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Nav Bar */}
      <nav className="fixed bottom-0 left-0 right-0 h-24 bg-bg-main/80 backdrop-blur-xl border-t border-border-main z-50 px-10">
        <div className="max-w-md mx-auto h-full flex items-center justify-between">
          <button 
            onClick={() => setActiveTab('daily')}
            className={`group flex flex-col items-center gap-1 transition-all ${activeTab === 'daily' ? 'text-brand-primary' : 'text-text-main/30'}`}
          >
            <Activity size={28} className={`${activeTab === 'daily' ? 'scale-110' : 'group-hover:scale-105'} transition-transform`} />
            <span className="text-[10px] font-bold uppercase tracking-widest">יומי</span>
          </button>
          <button 
            onClick={() => setActiveTab('teams')}
            className={`group flex flex-col items-center gap-1 transition-all ${activeTab === 'teams' ? 'text-brand-primary' : 'text-text-main/30'}`}
          >
            <Users size={28} className={`${activeTab === 'teams' ? 'scale-110' : 'group-hover:scale-105'} transition-transform`} />
            <span className="text-[10px] font-bold uppercase tracking-widest">קבוצות</span>
          </button>
          <button 
            onClick={() => setActiveTab('rewards')}
            className={`group flex flex-col items-center gap-1 transition-all ${activeTab === 'rewards' ? 'text-brand-primary' : 'text-text-main/30'}`}
          >
            <Trophy size={28} className={`${activeTab === 'rewards' ? 'scale-110' : 'group-hover:scale-105'} transition-transform`} />
            <span className="text-[10px] font-bold uppercase tracking-widest">פרסים</span>
          </button>
        </div>
      </nav>
      
      {/* Footer (Desktop) */}
      <footer className="hidden lg:flex fixed bottom-0 left-12 h-24 items-center text-[10px] font-bold uppercase tracking-widest opacity-20 z-50 pointer-events-none">
        © 2024 צעד קדימה — השראה בתנועה
      </footer>
    </div>
  );
}
