import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';

interface HistoryData {
  date: string;
  steps: number;
}

interface Props {
  data: HistoryData[];
}

export const HistoryChart = ({ data }: Props) => {
  // Translate dates to Hebrew days if needed or just use day of week
  const formattedData = [...data].reverse().map(d => ({
    ...d,
    label: new Date(d.date).toLocaleDateString('he-IL', { weekday: 'short' })
  }));

  return (
    <div className="w-full h-64 mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={formattedData}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E8E2DA" />
          <XAxis 
            dataKey="label" 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#4A443F', fontSize: 12, fontWeight: 600 }}
          />
          <YAxis hide />
          <Tooltip 
            cursor={{ fill: 'transparent' }}
            contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
          />
          <Bar dataKey="steps" radius={[10, 10, 0, 0]}>
            {formattedData.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={entry.steps >= 10000 ? '#8DA08E' : '#E6A982'} 
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
