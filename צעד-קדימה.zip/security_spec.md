# Security Specification for StepUp Portal

## 1. Data Invariants
- A `DailyRecord` must belong to the user identified by `userId`.
- A `TeamMember` entry must associate a valid `userId` with a valid `teamId`.
- `steps`, `calories`, and `distance` must be non-negative numbers.
- `dailyGoal` must be between 1,000 and 100,000.

## 2. The Dirty Dozen (Potential Vulnerabilities)
1. User A tries to read User B's step history.
2. User A tries to update User B's daily goal.
3. User A tries to create a TeamMember entry for User B without their consent.
4. User A tries to join a team without a valid invite code.
5. User A tries to inject a huge string into the `name` field of a team.
6. User A tries to set their `dailyGoal` to -500.
7. User A tries to spoof the `userId` in a `DailyRecord`.
8. User A tries to delete a Team they didn't create.
9. User A tries to increment someone else's step count using a batch write.
10. User A tries to read the `inviteCode` of a team they aren't in.
11. User A tries to modify the `createdAt` timestamp of a team.
12. User A tries to list all users to scrape PII.

## 3. Policy Enforcement
- `allow read, write: if false;` catch-all.
- `users/{userId}`: `allow read, write: if request.auth.uid == userId`.
- `teams/{teamId}`: `allow read: if isSignedIn();` (Basic info).
- `teams/{teamId}/members/{memberId}`: `allow read: if isMember(teamId); allow write: if request.auth.uid == memberId`.
